let express = require(`express`)
let app = express()
let port = 3005

app.listen(port, ()=>{
    console.log(`Сервер запущен http://localhost:${port}`)
})
app.use(express.static(`public`))
let hbs = require(`hbs`)
app.set('views', 'views')
app.set('view engine', 'hbs')
let name
let phone
let service
app.get(`/`, (req,res)=>{
    name = req.query.username
    phone = req.query.phone
    service = req.query.service
    res.render(`index`)
})

app.get(`/send`, (req, res)=>{
    res.render(`send`)
    
    
})