let express = require(`express`);
let app = express();
let port = 3000;

app.listen(port, function () {
    console.log(`http://localhost:${3000}`);
});

app.use(express.static(`public`));


// Настройка handlebars
let hbs = require('hbs');
app.set('views', 'views');
app.set('view engine', 'hbs');



app.get(`/`, function (req, res){
    let color = req.query.color

        res.render("index",{
            answer: "Ответ",
            color: color,
        })
    
    
});



