let express = require(`express`)
let app = express()
let port = 3005

app.listen(port, ()=>{
    console.log(`Сервер запущен http://localhost:${port}`)
})
app.use(express.static(`public`))
let hbs = require(`hbs`)
app.set('views', 'views')
app.set('view engine', 'hbs')
let work_ls = []

app.get(`/`, (req, res)=> {
    let work = req.query.work
    work_ls.push(work)

    res.render(`index`, {
        work_ls
    })
    
})

app.get(`/clear`, (req, res)=>{
    res.render(`index`)
})