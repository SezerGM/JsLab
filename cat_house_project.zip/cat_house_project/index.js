let express = require(`express`)
let app = express()

let port = 3005
let { faker } = require('@faker-js/faker')

app.listen(port, ()=>{

    console.log(`Сервер запущен http://localhost:${port}`)
})

app.use(express.static(`public`))
const urlencodedParser = express.urlencoded({extended: false});
let hbs  = require(`hbs`)
app.set('views', 'views')
app.set('view engine', 'hbs')

function getRandomFloat(min, max, decimals) {
    const str = (Math.random() * (max - min) + min).toFixed(
      decimals,
    );
  
    return parseFloat(str);
  }

  

let data = [
        {img: faker.image.cats(200, 200, true),
        name: faker.person.firstName(),
        age: faker.number.int({min: 0, max: 25}),
        breed: faker.animal.cat(),
        stock: true,
        sex: faker.datatype.boolean(getRandomFloat(0.0, 1.0, 0.5)),
        request: false},
        {img: faker.image.cats(200, 200, true),
        name: faker.person.firstName(),
        age: faker.number.int({min: 0, max: 25}),
        breed: faker.animal.cat(),
        stock: true,
        sex: faker.datatype.boolean(getRandomFloat(0.0, 1.0, 0.5)),
        request: false},
        {img: faker.image.cats(200, 200, true),
        name: faker.person.firstName(),
        age: faker.number.int({min: 0, max: 25}),
        breed: faker.animal.cat(),
        stock: true,
        sex: faker.datatype.boolean(getRandomFloat(0.0, 1.0, 0.5)),
        request: false},
        {img: faker.image.cats(200, 200, true),
        name: faker.person.firstName(),
        age: faker.number.int({min: 0, max: 25}),
        breed: faker.animal.cat(),
        stock: true,
        sex: faker.datatype.boolean(getRandomFloat(0.0, 1.0, 0.5)),
        request: false},
        {img: faker.image.cats(200, 200, true),
        name: faker.person.firstName(),
        age: faker.number.int({min: 0, max: 25}),
        breed: faker.animal.cat(),
        stock: true,
        sex: faker.datatype.boolean(getRandomFloat(0.0, 1.0, 0.5)),
        request: false},
        {img: faker.image.cats(200, 200, true),
        name: faker.person.firstName(),
        age: faker.number.int({min: 0, max: 25}),
        breed: faker.animal.cat(),
        stock: true,
        sex: faker.datatype.boolean(getRandomFloat(0.0, 1.0, 0.5)),
        request: false},
        {img: faker.image.cats(200, 200, true),
        name: faker.person.firstName(),
        age: faker.number.int({min: 0, max: 25}),
        breed: faker.animal.cat(),
        stock: true,
        sex: faker.datatype.boolean(getRandomFloat(0.0, 1.0, 0.5)),
        request: false},
        {img: faker.image.cats(200, 200, true),
        name: faker.person.firstName(),
        age: faker.number.int({min: 0, max: 25}),
        breed: faker.animal.cat(),
        stock: true,
        sex: faker.datatype.boolean(getRandomFloat(0.0, 1.0, 0.5)),
        request: false},
]



app.get(`/`, (req, res)=>{
    
    res.render('index.hbs', {data})
    
})

app.get(`/admin`, (req, res)=>{
    
    res.render(`admin`, {data})
})

app.get(`/take`, (req,res)=>{
    id = req.query.id
    data[id].request = true   
    res.redirect(`/`)
    })

app.get(`/remove`, (req, res)=>{
  let id1 = req.query.id1
  data[id1].stock = false
  res.redirect(`/admin`)
})

app.get(`/add`,(req, res)=>{
  let name = req.query.name;
  let age = req.query.age;
  let breed =  req.query.breed;
  let sex = req.query.sex;

  if(sex == 'male' && 'Male'){
    data.push({img: faker.image.cats(200, 200, true), name: name, age: age, breed: breed, stock: true,
      sex: true,
      request: false})
  }else{
    data.push({img: faker.image.cats(200, 200, true), name: name, age: age, breed: breed, stock: true,
      sex: false,
      request: false})
  }
  
  console.log(data)
  res.redirect(`/admin`)
})